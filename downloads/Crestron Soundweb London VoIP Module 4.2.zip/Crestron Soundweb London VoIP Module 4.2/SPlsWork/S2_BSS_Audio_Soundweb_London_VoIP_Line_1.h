#ifndef __S2_BSS_AUDIO_SOUNDWEB_LONDON_VOIP_LINE_1_H__
#define __S2_BSS_AUDIO_SOUNDWEB_LONDON_VOIP_LINE_1_H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SUBSCRIBE$_DIG_INPUT 0
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_UNSUBSCRIBE$_DIG_INPUT 1
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_METER_SUBSCRIBE$_DIG_INPUT 2
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_CALLER_ID_SUBSCRIBE$_DIG_INPUT 3
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_1$_DIG_INPUT 4
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_2$_DIG_INPUT 5
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_3$_DIG_INPUT 6
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_4$_DIG_INPUT 7
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_5$_DIG_INPUT 8
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_6$_DIG_INPUT 9
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_7$_DIG_INPUT 10
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_8$_DIG_INPUT 11
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_9$_DIG_INPUT 12
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_0$_DIG_INPUT 13
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_PAUSE$_DIG_INPUT 14
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_DELETE$_DIG_INPUT 15
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_REDIAL$_DIG_INPUT 16
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_BACKSPACE$_DIG_INPUT 17
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON___LB__$_DIG_INPUT 18
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_ASTERISK$_DIG_INPUT 19
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_HOLD_TOGGLE$_DIG_INPUT 20
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_REJECT$_DIG_INPUT 21
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_GAINBUMPUP$_DIG_INPUT 22
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_GAINBUMPDWN$_DIG_INPUT 23
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_BUTTON_PICKUPHANGUP$_DIG_INPUT 24
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RINGER_TOG$_DIG_INPUT 25
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWERON$_DIG_INPUT 26
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWEROFF$_DIG_INPUT 27
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWER_TOGGLE$_DIG_INPUT 28
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_MUTEON$_DIG_INPUT 29
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_MUTEOFF$_DIG_INPUT 30
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_MUTETOGGLE$_DIG_INPUT 31
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_MUTEON$_DIG_INPUT 32
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_MUTEOFF$_DIG_INPUT 33
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_MUTETOGGLE$_DIG_INPUT 34
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_MUTEON$_DIG_INPUT 35
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_MUTEOFF$_DIG_INPUT 36
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_MUTETOGGLE$_DIG_INPUT 37

#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_STORE$_DIG_INPUT 38
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_STORE$_ARRAY_LENGTH 16
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_DIAL$_DIG_INPUT 54
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_DIAL$_ARRAY_LENGTH 16

/*
* ANALOG_INPUT
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWER_RINGS$_ANALOG_INPUT 0
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_GAIN$_ANALOG_INPUT 1
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_GAIN$_ANALOG_INPUT 2
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_GAIN$_ANALOG_INPUT 3
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RING_GAIN$_ANALOG_INPUT 4

#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONE_NUMBER$_STRING_INPUT 5
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONE_NUMBER$_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONE_NUMBER$, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONE_NUMBER$_STRING_MAX_LEN );

#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX$_BUFFER_INPUT 6
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX$_BUFFER_MAX_LEN 1000
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __RX$, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX$_BUFFER_MAX_LEN );


/*
* DIGITAL_OUTPUT
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_INCOMING_CALL_FB$_DIG_OUTPUT 0
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_LINE_STATUS_FB$_DIG_OUTPUT 1
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_HOLD_FB$_DIG_OUTPUT 2
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_HOOK_STATUS_FB$_DIG_OUTPUT 3
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RINGER_FB$_DIG_OUTPUT 4
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWER_FB$_DIG_OUTPUT 5
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_MUTE_FB$_DIG_OUTPUT 6
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_MUTE_FB$_DIG_OUTPUT 7
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_MUTE_FB$_DIG_OUTPUT 8

#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_DIAL_FB$_DIG_OUTPUT 9
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_SPEED_DIAL_FB$_ARRAY_LENGTH 16

/*
* ANALOG_OUTPUT
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_AUTO_ANSWER_RINGS_FB$_ANALOG_OUTPUT 0
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_GAIN_FB$_ANALOG_OUTPUT 1
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX_METER_FB$_ANALOG_OUTPUT 2
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_GAIN_FB$_ANALOG_OUTPUT 3
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RX_METER_FB$_ANALOG_OUTPUT 4
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_DTMF_GAIN_FB$_ANALOG_OUTPUT 5
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RING_GAIN_FB$_ANALOG_OUTPUT 6

#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONE_NUMBER_FB$_STRING_OUTPUT 7
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_CALLER_ID_FB$_STRING_OUTPUT 8
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TX$_STRING_OUTPUT 9


/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_METER_RATE$_INTEGER_PARAMETER 10
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_CALLER_ID_RATE$_INTEGER_PARAMETER 11
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TEMPSTRING_STRING_MAX_LEN 40
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __TEMPSTRING, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TEMPSTRING_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RETURNSTRING_STRING_MAX_LEN 4
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __RETURNSTRING, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_RETURNSTRING_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR1_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR1, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR1_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR2_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR2, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR2_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR3_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR3, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_MAINSTR3_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TELENUMBER_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __TELENUMBER, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_TELENUMBER_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONETEST1_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONETEST1, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONETEST1_STRING_MAX_LEN );
#define __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONETEST2_STRING_MAX_LEN 32
CREATE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONETEST2, __S2_BSS_Audio_Soundweb_London_VoIP_Line_1_PHONETEST2_STRING_MAX_LEN );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1 )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __SPEED_STORE$ );
   DECLARE_IO_ARRAY( __SPEED_DIAL$ );
   DECLARE_IO_ARRAY( __SPEED_DIAL_FB$ );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONE_NUMBER$ );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __RX$ );
};

START_NVRAM_VAR_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1 )
{
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __TEMPSTRING );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __RETURNSTRING );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR1 );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR2 );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __MAINSTR3 );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __TELENUMBER );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONETEST1 );
   DECLARE_STRING_STRUCT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __PHONETEST2 );
   unsigned short __XOK;
   unsigned short __RETURNI;
   unsigned short __SUBSCRIBE;
   unsigned short __XOKSUBSCRIBE;
   unsigned short __METER_SUBSCRIBE;
   unsigned short __I;
   unsigned short __XSAVE;
   unsigned short __XDIAL;
   unsigned short __STATEVARVALUE;
   unsigned short __STATEVARPHANTOM;
   unsigned short __STATEVARRECEIVE;
   unsigned short __STATEVARSAVE;
   unsigned short __STATEVARDIAL;
   unsigned short __VOLUMEINPUT;
   unsigned short __VOLUME;
   unsigned short __TX_GAIN;
   unsigned short __XOKTX_GAIN;
   unsigned short __RX_GAIN;
   unsigned short __XOKRX_GAIN;
   unsigned short __DTMF_GAIN;
   unsigned short __XOKDTMF_GAIN;
   unsigned short __RING_GAIN;
   unsigned short __XOKRING_GAIN;
   unsigned short __MAINREC1;
   unsigned short __MAINREC2;
   unsigned short __MAINREC3;
};

DEFINE_WAITEVENT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __SPLS_TMPVAR__WAITLABEL_0__ );
DEFINE_WAITEVENT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __SPLS_TMPVAR__WAITLABEL_1__ );
DEFINE_WAITEVENT( S2_BSS_Audio_Soundweb_London_VoIP_Line_1, __SPLS_TMPVAR__WAITLABEL_2__ );


#endif //__S2_BSS_AUDIO_SOUNDWEB_LONDON_VOIP_LINE_1_H__

