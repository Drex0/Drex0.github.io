File created 12-12-2016
CBGB Harman Conference Room

This is a working dialer for the SoundwebLondon BLU103 VOIP dialer. Not everything in GUI finished. This file should be used only as an exmaple of how to control the VOIP card.

Attached example Audio Arhcitect design file: DBGB BLU-103.audioarchitect

Attached AMX workspace: Harman.AXW

NOTE: The Caller ID is a subscription that will continually receive feedback based on BSS meter metrics. May flood AMX system. Possible to introduce a structure to only subscribe to CID when incoming call and clear when pickup/hangup goes low.


Email for questions:
Patrick Zachman
pzachman@gmail.com
www.zachmanor.com